#include "stdafx.h"

int find(int a[8][8]);