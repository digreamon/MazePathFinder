// Way.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "f.h"
#include <iostream>
//#include <ctime>// include this header
//#include <windows.h>
using namespace std;

void showArr(int[8][8]);

int lab1 [8][8] = 
{
	{0, 0, 0, 0, 1, 0, 0, 0},
	{0, 1, 0, 1, 1, 1, 1, 0},
	{0, 1, 0, 0, 0, 0, 1, 0},
	{0, 1, 1, 1, 1, 0, 1, 0},
	{1, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 0, 1, 1},
	{0, 1, 0, 1, 0, 0, 1, 0},
	{0, 0, 0, 1, 0, 0, 0, 0}
};//10

int lab2 [8][8] = 
{
	{0, 0, 0, 0, 0, 0, 1, 0},
	{1, 1, 0, 1, 0, 0, 1, 0},
	{0, 0, 0, 1, 1, 0, 1, 0},
	{0, 0, 1, 0, 0, 0, 1, 1},
	{1, 1, 0, 0, 0, 1, 0, 0},
	{1, 0, 0, 1, 1, 1, 0, 0},
	{1, 1, 0, 1, 0, 1, 0, 1},
	{0, 0, 0, 1, 0, 0, 0, 0}
};//10

int lab3 [8][8] = 
{
	{0, 1, 0, 0, 0, 0, 0, 0},
	{0, 1, 0, 1, 0, 1, 0, 0},
	{0, 0, 0, 1, 0, 1, 0, 0},
	{1, 1, 1, 1, 0, 1, 0, 0},
	{0, 0, 0, 0, 0, 1, 1, 0},
	{0, 1, 1, 1, 1, 0, 1, 0},
	{0, 0, 0, 0, 0, 0, 1, 0},
	{0, 1, 1, 1, 1, 1, 0, 0}
};//12

int lab4 [8][8] = 
{
	{0, 0, 0, 0, 0, 0, 0, 1},
	{1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 0, 0, 1, 1, 0, 1},
	{0, 1, 1, 0, 1, 1, 0, 1},
	{0, 1, 0, 0, 1, 1, 0, 1},
	{0, 1, 0, 0, 0, 0, 1, 1},
	{0, 1, 1, 1, 1, 1, 1, 1},
	{0, 0, 0, 0, 0, 0, 0, 0}
};//27

int lab5 [8][8] = 
{
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 0, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {1, 1, 1, 1, 1, 1, 1, 0}
};// 12

int lab6 [8][8] = 
{
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 1, 1, 1, 0, 1},
            {1, 1, 0, 0, 1, 1, 0, 1},
            {1, 1, 1, 0, 0, 1, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {0, 1, 1, 1, 1, 1, 1, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 0}
};//13

int lab7 [8][8] = 
{
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 0, 0, 1, 1, 0, 1},
            {1, 1, 1, 0, 0, 1, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {0, 1, 1, 1, 1, 1, 1, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 0}
};// 21

int lab8 [8][8] = 
{
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 0, 0, 1, 1, 0, 1},
            {1, 0, 1, 0, 0, 1, 0, 1},
            {0, 0, 1, 1, 1, 0, 0, 1},
            {0, 1, 1, 1, 1, 1, 1, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 0}
};// 22

int lab9 [8][8] = 
{
	{0, 1, 1, 0, 0, 0, 1, 1},
	{0, 0, 1, 0, 1, 0, 1, 0},
	{0, 1, 1, 0, 1, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 0, 0},
	{1, 1, 1, 1, 1, 0, 1, 0},
	{0, 1, 1, 0, 1, 0, 1, 0},
	{0, 0, 0, 0, 0, 1, 1, 1},
	{1, 1, 1, 1, 0, 1, 0, 0}
};//-1

int lab10 [8][8] = 
{
            {1, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 0, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 0}
};// -1 (boundary condition)

int lab11 [8][8] = 
{
            {1, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 0, 0, 1, 1, 0, 1},
            {1, 0, 1, 0, 0, 1, 0, 1},
            {0, 0, 1, 1, 1, 0, 0, 1},
            {0, 1, 1, 1, 1, 1, 1, 1},
            {0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 0}
};// -1 (boundary condition)


int _tmain(int argc, _TCHAR* argv[])
{
	/*	
	__int64 CounterStart = 0;
	LARGE_INTEGER li;
	QueryPerformanceCounter(&li);
	double PCFreq = double(li.QuadPart)/1000.0;
	*/
	
	bool failed[11];
	for(int i=0; i<11; i++)
		failed[i] = false;
	
	//CounterStart = li.QuadPart;

	if(find(lab1) != 10)
		failed[0] = true;

	if(find(lab2) != 10) 
		failed[1] = true;

	if(find(lab3) != 12) 
		failed[2] = true;

	if(find(lab4) != 27) 
		failed[3] = true;

	if(find(lab5) != 12) 
		failed[4] = true;

	if(find(lab6) != 13) 
		failed[5] = true;

	if(find(lab7) != 21) 
		failed[6] = true;

	if(find(lab8) != 22) 
		failed[7] = true;

	if(find(lab9) != -1) 
		failed[8] = true;

	if(find(lab10) != -1) 
		failed[9] = true;

	if(find(lab11) != -1) 
		failed[10] = true;

	//QueryPerformanceCounter(&li);
    //double dTime = double(li.QuadPart-CounterStart)/PCFreq;

	//cout << "Execution time: " << dTime << endl;
	int counter = 11;
	for(int i=0; i<11; i++)
	{
		if(failed[i])
		{
			counter--;
			cout<<"Test "<<i+1<<" failed.";
			if(i==8)
				cout<<" It was \"No way\" test."<<endl;
			else if(i==10 || i==9)
				cout<<" It was \"Special condition\" test."<<endl;
			else
				cout<<endl;
		}
	}

	cout<<"\nYour score is "<<counter<<"/11."<<endl;
	cin.get();

	return 0;
}
/*
void showArr(int a[8][8])
{
	for(int i=0; i<8; i++)
	{
		for(int j=0; j<8; j++)
		{
			cout<<a[i][j]<<'\t';
		}
		cout<<endl;
	}
	cout<<endl;
	return;
}*/